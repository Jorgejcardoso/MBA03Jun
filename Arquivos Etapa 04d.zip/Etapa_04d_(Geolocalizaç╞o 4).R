# Disciplina: Big Data Analytics com R
# Construir visualiza��es de dados utilizando mapas integrados a outras bases de informa��o

# -------------------------
# GEOLOCALIZA��O
# AUTOR: Francisco Rodriguez-Sanchez (Adaptado)
# -------------------------

# Instalando pacotes
#install.packages("sp", dependencies=TRUE)
#install.packages("raster", dependencies=TRUE)
#install.packages("rasterVis", dependencies=TRUE)
#install.packages("maptools", dependencies=TRUE)
#install.packages("rgeos", dependencies=TRUE)
#install.packages("dismo", dependencies=TRUE)
#install.packages("RgoogleMaps", dependencies=TRUE)

# Carregando pacotes.
library(sp) 
library(raster)
library(rasterVis) 
library(maptools)
library(rgeos)


# -------------------------
# MAPAS GEN�RICOS
# -------------------------

# Uma forma de capturar mapas do Google.
library(dismo) 

# Capturando o mapa do Brasil.
mymap <- gmap("Brazil")
plot(mymap)

# Capturando o mapa do Brasil, agora com a vis�o de sat�lite.
mymap <- gmap("Brazil", type = "satellite")
plot(mymap)

# Capturando o mapa do Brasil, com a vis�o de sat�lite e menor zoom.
mymap <- gmap("Brazil", type = "satellite", exp = 3)
plot(mymap)

# Gravando o mapa para uso futuro.
mymap <- gmap("Brazil", type = "satellite", filename = "Brasil")

# Capturando um mapa de uma regi�o escolhida.
mymap <- gmap("Europe")
plot(mymap)
select.area <- drawExtent() # Selecione uma �rea com dois cliques no mapa.
mymap <- gmap(select.area)
plot(mymap)

# -------------------------
# MAPEANDO DADOS EM MAPAS DO GOOGLE
# ------------------------

# Mais uma forma de capturar mapas do Google.
library(RgoogleMaps)

newmap <- GetMap(center = c(36.7, -5.9), zoom = 10, destfile = "newmap.png", 
                 maptype = "satellite")

# Usando 'bounding box' no lugar de 'center coordinates':
newmap2 <- GetMap.bbox(lonR = c(-5, -6), latR = c(36, 37), destfile = "newmap2.png", 
                       maptype = "terrain")

# Tentando 'maptypes' diferentes.
newmap3 <- GetMap.bbox(lonR = c(-5, -6), latR = c(36, 37), destfile = "newmap3.png", 
                       maptype = "satellite")

# Pegando o tamanho da imagem para uso no comando abaixo.
size <- dim(newmap[[4]])[2:1]

PlotOnStaticMap(lat = c(36.3, 35.8, 36.4), lon = c(-5.5, -5.6, -5.8), zoom = 10, 
                cex = 4, pch = 19, col = "red", FUN = points, add = F, size = size)

