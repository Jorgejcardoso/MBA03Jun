# Disciplina: Big Data Analytics com R
# 
# -------------------------
# COLETA, TRATAMENTO E PROCESSAMENTO DE POSTAGENS NO INSTAGRAM
# USO DA API DO INSTAGRAM
# ADAPTADO DE https://github.com/JulianHill/R-Tutorials/blob/master/r_instagram.r
# AUTOR: JULIAN HILLEBRAND
# -------------------------

# Instalando pacotes, este tamb�m n�o est� hospedado no CRAN.
#library(devtools)
#install_github("ramnathv/rCharts")

# Carregando pacotes.
library(httr)
library(rjson)
library(RCurl)
library(rCharts)

# Pegando a URL de callback necess�ria para configura��o da API.
full_url <- oauth_callback()
full_url <- gsub("(.*localhost:[0-9]{1,5}/).*", x=full_url, replacement="\\1")
message <- paste("Copy and paste into Site URL on Instagram App Settings:", 
                full_url, "\nWhen done, press any key to continue...")

invisible(readline(message))

# Dados para autentica��o.
#app_name <- ""
#client_id <- "XXX"
#client_secret <- "XXX"


# Este escopo � suficiente para capturar coment�rios.
# Para outros escopos, veja a documaneta��o da API.
scope = "basic"

# Autentica��o.
instagram <- oauth_endpoint(
  authorize = "https://api.instagram.com/oauth/authorize",
  access = "https://api.instagram.com/oauth/access_token")  
myapp <- oauth_app(app_name, client_id, client_secret)

# Pegando o token de acesso.
ig_oauth <- oauth2.0_token(instagram, myapp,scope="basic",  type = "application/x-www-form-urlencoded",cache=FALSE)  
tmp <- strsplit(toString(names(ig_oauth$credentials)), '"')
token <- tmp[[1]][4]

# Capturando posts recentes do pr�prio usu�rio.
media <- fromJSON(getURL(paste('https://api.instagram.com/v1/users/self/media/recent/?access_token=',token,sep="")))


# Criando um dataframe para coletar os dados.
df = data.frame(no = 1:length(media$data))

# Coletando contagem, coment�rios e likes.
for(i in 1:length(media$data))
{
  #comments
  df$comments[i] <-media$data[[i]]$comments$count
  
  #likes:
  df$likes[i] <- media$data[[i]]$likes$count
  
  #date
  df$date[i] <- toString(as.POSIXct(as.numeric(media$data[[i]]$created_time), origin="1970-01-01"))
}

# Gerando um gr�fico com a biblioteca rCharts.
m1 <- mPlot(x = "date", y = c("likes", "comments"), type = "Line", data = df)
m1

